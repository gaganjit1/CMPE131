<?php
include('/menu.php');
?>

<div class="container">
<h2 class="white">Make the Smart Decision<h2>
<br>
<h3 class="pink">OUR SOLUTION<h3>
<br>
<p class="white">We have developed an easy survey for undecided engineering students. Please click the link below to begin!</p>
<br>
<a class="pink" href="/">The Smart Major</a>

</div>