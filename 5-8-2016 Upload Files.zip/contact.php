<?php
include('/menu.php');
?>


<div class="container">
<h2 class="white">Contact Us<h2>
<br>
<h3 class="pink">SMART SOLUTIONS<h3>
<br>
<p class="white">One Washington Square</p>
<p class="white">San Jose, CA 95130</p>
<p class="white">engineers.are.us@smartmajor.com</p>
<br>
</div>