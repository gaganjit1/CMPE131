<?php
include('/menu.php');
?>

<div class="container">
<h2 class="white">About Us</h2>
<br>
<h3 class="pink">What is the Engineering Ambassador Program?</h3>
<p class="white">The Engineering Ambassador Program (EAP) is a San Jose State University Dean Affiliate Outreach Group whose mission 
is to teach younger students across the Bay Area about engineering. We set up activities to cultivate and demonstrate 
problem-solving skills, presentations to educate about the different disciplines, or hold panels to answer any question 
younger students may have. We host many type of events including: classroom visits, school tours, college nights, 
STEM outreach booths, and more. Our Ambassadors share their own passion for engineering in hopes to inspire the next 
generation of engineers. </p>
<br>
<h3 class="pink">Who Are We?</h3>
<p class="white">Melissa, Andrew, Gaganjit, Saif, and Megumi are Computer Engineering students at SJSU. In response to multiple class 
assignemnts, they have choosen to form a group to begin a Machine Learning project. This project has gained popularity 
and thus the team partnered with EAP. Therefore, these students have developed a survey that will enable undecided 
engineering students to recieve a major reccomendation. This project is ongoing and the algorithm will continue to be
modified for maximum optimization.</p>
</div>